import base64

KEY = "supersecretkey"


def encrypt(message):
    return base64.b64encode(xor_encrypt(message, KEY).encode()).decode()


# Incomplete decrypt function
# def decrypt():
#     return 


def xor_encrypt(message, key):
    return ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(message))
