from cryptography.fernet import Fernet

flag = b'YCEP24{REDACTED}'
key = b'UzCP0BWCLgd1kTX25dqHCOGUyttLPgXwB6dBrDybco4='
cipher_suite = Fernet(key)

def encrypt(message):
    """Encrypt a message."""
    return cipher_suite.encrypt(message)

# Encrypting the flag
encrypted_flag = encrypt(flag)
print(f'Encrypted: {encrypted_flag}')